"""Reporting and analysis helpers."""
